import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import 'package:google_mobile_ads/google_mobile_ads.dart'; // AdMob
import 'package:shared_preferences/shared_preferences.dart'; // Progress Tracking

// --- Custom MaterialColor Function and Constants (UPDATED) ---
// Custom function to create a MaterialColor from a single Color value
MaterialColor createMaterialColor(Color color) {
  List strengths = <double>[.05];
  final swatch = <int, Color>{};
  
  // FIX: Use .r, .g, .b component accessors instead of deprecated 'red', 'green', 'blue'
  final int r = color.red, g = color.green, b = color.blue; 

  for (int i = 1; i < 10; i++) {
    strengths.add(0.1 * i);
  }
  for (var strength in strengths) {
    final double ds = 0.5 - strength;
    swatch[(strength * 1000).round()] = Color.fromRGBO(
      r + ((ds < 0 ? r : (255 - r)) * ds).round(),
      g + ((ds < 0 ? g : (255 - g)) * ds).round(),
      b + ((ds < 0 ? b : (255 - b)) * ds).round(),
      1,
    );
  }
  // FIX: .value is not deprecated for MaterialColor constructor, but we keep it simple.
  return MaterialColor(color.value, swatch);
}

// -------------------------------------------------------------------
final MaterialColor kPrimaryColor = createMaterialColor(const Color(0xFF00897B)); // Deep Teal
final MaterialColor kAccentColor = createMaterialColor(const Color(0xFF673AB7));  // Deep Purple
// Test Ad IDs (For Debugging/Testing purposes only)
const String kBannerAdUnitId = 'ca-app-pub-3940256099942544/6300978111'; // Test Banner
const String kInterstitialAdUnitId = 'ca-app-pub-3940256099942544/1033173712'; // Test Interstitial
// -------------------------------------------------------------------

const Color kBackgroundColor = Color(0xFFF5F5F5); 
const Color kCardColor = Colors.white;
const Color kTextColor = Colors.white;
const double kPadding = 20.0;
const Duration kTileMoveDuration = Duration(milliseconds: 250);

// --- Main App Widget with AdMob and SharedPreferences Initialization ---
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // AdMob SDK को शुरू करना
  MobileAds.instance.initialize();
  runApp(const PuzzleApp());
}

class PuzzleApp extends StatelessWidget {
  const PuzzleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pro Puzzle Game',
      debugShowCheckedModeBanner: false, 
      theme: ThemeData(
        // FIX: 'background' is deprecated. Using 'surface' for M3 theming.
        colorScheme: ColorScheme.fromSeed(
          seedColor: kPrimaryColor,
          primary: kPrimaryColor,
          secondary: kAccentColor,
          surface: kBackgroundColor, // FIX: Changed background to surface
        ),
        scaffoldBackgroundColor: kBackgroundColor,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          titleTextStyle: TextStyle(
            color: Colors.black87,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
          iconTheme: IconThemeData(color: Colors.black87),
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(), 
    );
  }
}

// -------------------------------------------------------------------
// --- 1. Splash Screen (with FIX) ---
// -------------------------------------------------------------------
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          PageRouteBuilder(
            transitionDuration: const Duration(milliseconds: 800),
            pageBuilder: (_, __, ___) => const HomeScreen(),
            transitionsBuilder: (_, animation, __, child) {
              return FadeTransition(
                opacity: animation,
                child: child,
              );
            },
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor, 
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: kAccentColor,
                borderRadius: BorderRadius.circular(15),
              ),
              child: const Icon(Icons.grid_view_sharp, color: kTextColor, size: 60),
            ),
            const SizedBox(height: 20),
            const Text(
              'SLIDE MASTER',
              style: TextStyle(
                color: kTextColor,
                fontSize: 48,
                fontWeight: FontWeight.w900,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 50),
            SizedBox(
              width: 50,
              height: 50,
              child: CircularProgressIndicator(
                // FIX: Used .withAlpha instead of deprecated .withOpacity
                valueColor: AlwaysStoppedAnimation<Color>(kTextColor.withAlpha((255 * 0.9).round())),
                strokeWidth: 4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// -------------------------------------------------------------------
// --- 2. Home Screen (No logic change, only minor UI fix) ---
// -------------------------------------------------------------------
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<int> gridSizes = const [3, 4, 5, 6, 7, 8];
  Set<String> _completedLevels = {};
  InterstitialAd? _interstitialAd;
  int _completedCount = 0;

  @override
  void initState() {
    super.initState();
    _loadProgress();
    _loadInterstitialAd();
  }
  
  // --- Progress Logic (SAME) ---
  Future<void> _loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final keys = prefs.getKeys().where((key) => key.startsWith('completed_'));
    
    _completedLevels = keys.map((key) => key.split('_').last).toSet();
    _completedCount = _completedLevels.length;
    
    if (mounted) {
      setState(() {});
    }
  }

  // --- AdMob Logic (SAME) ---
  void _loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: kInterstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              ad.dispose();
              _interstitialAd = null;
              _loadInterstitialAd(); 
            },
            onAdFailedToShowFullScreenContent: (ad, error) {
              ad.dispose();
              _interstitialAd = null;
              _loadInterstitialAd();
            },
          );
        },
        onAdFailedToLoad: (LoadAdError error) {
          _interstitialAd = null;
        },
      ),
    );
  }
  
  @override
  void dispose() {
    _interstitialAd?.dispose();
    super.dispose();
  }

  // --- UI and Level Card Builder (SAME) ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text('Select Puzzle Grid', style: TextStyle(color: Colors.black87)),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline, color: Colors.black87),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('You have completed $_completedCount levels. 2 required to unlock 7x7 and 8x8.'),
                  duration: const Duration(seconds: 3),
                ),
              );
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadProgress,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(kPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: gridSizes.map((size) {
              final bool needsUnlock = size >= 7;
              final bool isLocked = needsUnlock && (_completedCount < 2);
              
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: _buildLevelCard(
                  context,
                  size: size,
                  isLocked: isLocked,
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  Widget _buildLevelCard(BuildContext context, {required int size, required bool isLocked}) {
    String difficulty;
    IconData icon;
    Color color;

    if (size <= 4) {
      difficulty = 'Easy';
      icon = Icons.star;
      color = Colors.green.shade600;
    } else if (size <= 6) {
      difficulty = 'Medium';
      icon = Icons.star_half;
      color = Colors.orange.shade600;
    } else {
      difficulty = 'Hard';
      icon = isLocked ? Icons.lock_outline : Icons.diamond;
      color = isLocked ? Colors.grey.shade600 : kAccentColor;
    }

    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: InkWell(
        onTap: () async {
          if (isLocked) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text(
                  'Please complete two other levels first to unlock this!',
                  style: TextStyle(color: kTextColor),
                ),
                backgroundColor: Colors.redAccent,
                duration: Duration(seconds: 2),
              ),
            );
          } else {
            await Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => GameScreen(gridSize: size, interstitialAd: _interstitialAd, onWin: _loadProgress),
              ),
            );
            if (_interstitialAd == null) {
              _loadInterstitialAd();
            }
          }
        },
        borderRadius: BorderRadius.circular(15),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: isLocked ? Colors.grey.shade300 : kCardColor,
          ),
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
          child: Row(
            children: [
              Icon(icon, color: isLocked ? Colors.grey.shade600 : color, size: 30),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${size}x$size Puzzle',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: isLocked ? Colors.grey.shade600 : Colors.black87,
                      ),
                    ),
                    Text(
                      difficulty,
                      style: TextStyle(
                        fontSize: 16,
                        color: isLocked ? Colors.grey.shade500 : color,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              if (isLocked)
                Icon(Icons.lock, color: Colors.grey.shade600, size: 30),
            ],
          ),
        ),
      ),
    );
  }
}

// -------------------------------------------------------------------
// --- 3. Game Screen (No logic change, only minor UI fix) ---
// -------------------------------------------------------------------
class GameScreen extends StatefulWidget {
  final int gridSize;
  final InterstitialAd? interstitialAd;
  final VoidCallback onWin; 
  
  const GameScreen({
    super.key, 
    required this.gridSize, 
    this.interstitialAd,
    required this.onWin,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  // Banner Ad Variables
  BannerAd? _bannerAd;
  bool _isBannerAdLoaded = false;
  
  late List<int> tiles;
  late int blankIndex;
  Timer? _timer;
  int _secondsElapsed = 0;
  int _moveCount = 0; 
  bool _isGameOver = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd(); 
    _initializeGame();
  }
  
  // Banner Ad Logic (SAME)
  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: kBannerAdUnitId,
      request: const AdRequest(),
      size: AdSize.banner,
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          if (mounted) {
            setState(() {
              _isBannerAdLoaded = true;
            });
          }
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          _isBannerAdLoaded = false;
        },
      ),
    )..load(); 
  }

  // --- Game Logic (SAME) ---
  void _initializeGame() {
    final int totalTiles = widget.gridSize * widget.gridSize;
    tiles = List.generate(totalTiles, (i) => i + 1);
    tiles[totalTiles - 1] = 0;

    _shuffle();
    blankIndex = tiles.indexOf(0);

    _secondsElapsed = 0;
    _moveCount = 0;
    _isGameOver = false;
    _startTimer();
  }
  
  int _getInversions(List<int> currentTiles, int blankValue) {
    int inversions = 0;
    List<int> effectiveTiles = currentTiles.where((t) => t != blankValue).toList();
    for (int i = 0; i < effectiveTiles.length; i++) {
      for (int j = i + 1; j < effectiveTiles.length; j++) {
        if (effectiveTiles[i] > effectiveTiles[j]) {
          inversions++;
        }
      }
    }
    return inversions;
  }

  void _shuffle() {
    final int size = widget.gridSize;
    final int totalTiles = size * size;
    List<int> shufflableTiles;
    int inversions;
    int blankRow;

    do {
      shufflableTiles = List<int>.generate(totalTiles, (i) => i);
      shufflableTiles.shuffle(Random());

      int zeroIndex = shufflableTiles.indexOf(0);
      shufflableTiles.removeAt(zeroIndex);
      shufflableTiles.add(0);
      tiles = List.from(shufflableTiles);

      blankIndex = tiles.indexOf(0);
      blankRow = blankIndex ~/ size;
      inversions = _getInversions(tiles, 0);

      if (size % 2 != 0) {
        if (inversions % 2 == 0) break;
      } else {
        int blankRowFromBottom = size - blankRow;
        if ((blankRowFromBottom % 2 == 1) == (inversions % 2 == 0)) {
           break;
        }
      }
    } while (true);
    blankIndex = tiles.indexOf(0);
  }
  
  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isGameOver && mounted) {
        setState(() {
          _secondsElapsed++;
        });
      } else if (_isGameOver) {
        timer.cancel();
      }
    });
  }
  
  void _onTileTap(int index) {
    if (_isGameOver) return;

    if (_isValidMove(index, blankIndex)) {
      setState(() {
        _swapTiles(index, blankIndex);
        blankIndex = index;
        _moveCount++; 

        if (_checkWin()) {
          _isGameOver = true;
          _timer?.cancel();
          _saveWinProgress(widget.gridSize.toString()); 
          _showWinDialog();
          
          if (widget.interstitialAd != null) {
            widget.interstitialAd!.show();
          }
        }
      });
    }
  }

  bool _isValidMove(int tappedIndex, int blank) {
    int size = widget.gridSize;
    int tappedRow = tappedIndex ~/ size;
    int tappedCol = tappedIndex % size;
    int blankRow = blank ~/ size;
    int blankCol = blank % size;

    if (tappedRow == blankRow && (tappedCol - blankCol).abs() == 1) return true;
    if (tappedCol == blankCol && (tappedRow - blankRow).abs() == 1) return true;

    return false;
  }

  void _swapTiles(int index1, int index2) {
    int temp = tiles[index1];
    tiles[index1] = tiles[index2];
    tiles[index2] = temp;
  }

  bool _checkWin() {
    final int totalTiles = widget.gridSize * widget.gridSize;
    for (int i = 0; i < totalTiles - 1; i++) {
      if (tiles[i] != i + 1) {
        return false;
      }
    }
    return tiles[totalTiles - 1] == 0;
  }

  String _formatTime(int seconds) {
    final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$secs';
  }

  Future<void> _saveWinProgress(String size) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('completed_$size', true);
    widget.onWin(); 
  }

  @override
  void dispose() {
    _timer?.cancel();
    _bannerAd?.dispose();
    super.dispose();
  }

// -------------------------------------------------------------------
// --- UI: Game Board and Display (Banner Ad Integration) ---
// -------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black87),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          '${widget.gridSize}x${widget.gridSize} Puzzle',
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.black87),
            onPressed: _initializeGame,
          ),
          const SizedBox(width: kPadding / 2),
        ],
      ),
      body: Center(
        child: Column(
          children: [
            // Stats Row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: kPadding, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildStatPill(
                    icon: Icons.timer,
                    label: 'TIME',
                    value: _formatTime(_secondsElapsed),
                    color: kAccentColor,
                  ),
                  _buildStatPill(
                    icon: Icons.swap_horiz,
                    label: 'MOVES',
                    value: _moveCount.toString(),
                    color: kPrimaryColor,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            
            // Banner Ad Display
            if (_isBannerAdLoaded && _bannerAd != null)
              SizedBox(
                width: _bannerAd!.size.width.toDouble(),
                height: _bannerAd!.size.height.toDouble(),
                child: AdWidget(ad: _bannerAd!),
              )
            else
              Container(
                height: 50,
                width: double.infinity,
                color: Colors.grey.shade200,
                alignment: Alignment.center,
                child: const Text('Ad Loading...', style: TextStyle(color: Colors.black54)),
              ),
              
            const SizedBox(height: 20),
            
            // The Puzzle Grid
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(kPadding),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final size = min(constraints.maxWidth, constraints.maxHeight);
                    return Container(
                      width: size,
                      height: size,
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(15.0),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withAlpha((255 * 0.2).round()), // FIX
                            offset: const Offset(0, 5),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: widget.gridSize,
                          crossAxisSpacing: 8.0,
                          mainAxisSpacing: 8.0,
                        ),
                        itemCount: tiles.length,
                        itemBuilder: (context, index) {
                          final tileNumber = tiles[index];
                          if (tileNumber == 0) {
                            return Container(
                              decoration: BoxDecoration(
                                color: kBackgroundColor,
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            );
                          }
                          return _AnimatedTile(
                            number: tileNumber,
                            currentIndex: index,
                            gridSize: widget.gridSize,
                            onTap: _onTileTap,
                            blankIndex: blankIndex,
                          );
                        },
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  // Helper for professional stat display (with FIX)
  Widget _buildStatPill({required IconData icon, required String label, required String value, required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: color.withAlpha((255 * 0.3).round()), // FIX
            offset: const Offset(0, 3),
            blurRadius: 5,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: kTextColor, size: 20),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  color: kTextColor,
                  fontSize: 10,
                  fontWeight: FontWeight.w400,
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  color: kTextColor,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- UI: Win Dialog (with FIX) ---
  void _showWinDialog() {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      transitionDuration: const Duration(milliseconds: 500), 
      transitionBuilder: (context, a1, a2, child) {
        return ScaleTransition(
          scale: a1,
          child: child,
        );
      },
      pageBuilder: (context, a1, a2) {
        return AlertDialog(
          backgroundColor: kCardColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
          title: const Column(
            children: [
              Icon(Icons.emoji_events, color: Colors.amber, size: 50),
              SizedBox(height: 10),
              Text(
                'PUZZLE SOLVED!',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF00897B), fontSize: 24),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'You finished the ${widget.gridSize}x${widget.gridSize} puzzle!',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, color: Colors.black87),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // FIX: Used .withAlpha instead of deprecated .withOpacity
                  _buildStatPill(icon: Icons.timer, label: 'Time', value: _formatTime(_secondsElapsed), color: const Color(0xFF673AB7).withAlpha((255 * 0.8).round())),
                  const SizedBox(width: 10),
                  // FIX: Used .withAlpha instead of deprecated .withOpacity
                  _buildStatPill(icon: Icons.swap_horiz, label: 'Moves', value: _moveCount.toString(), color: const Color(0xFF00897B).withAlpha((255 * 0.8).round())),
                ],
              ),
            ],
          ),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  _initializeGame();
                });
              },
              style: TextButton.styleFrom(
                backgroundColor: kPrimaryColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                minimumSize: const Size(120, 45),
              ),
              child: const Text('Play Again', style: TextStyle(color: kTextColor, fontWeight: FontWeight.bold)),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop(); 
              },
              style: TextButton.styleFrom(
                backgroundColor: kAccentColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                minimumSize: const Size(120, 45),
              ),
              child: const Text('Levels', style: TextStyle(color: kTextColor, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }
}

// -------------------------------------------------------------------
// --- Custom Animated Tile Widget (with FIX) ---
// -------------------------------------------------------------------
class _AnimatedTile extends StatelessWidget {
  final int number;
  final int currentIndex;
  final int gridSize;
  final int blankIndex;
  final Function(int) onTap;

  const _AnimatedTile({
    required this.number,
    required this.currentIndex,
    required this.gridSize,
    required this.onTap,
    required this.blankIndex,
  });

  bool get isMovable {
    int size = gridSize;
    int tappedRow = currentIndex ~/ size;
    int tappedCol = currentIndex % size;
    int blankRow = blankIndex ~/ size;
    int blankCol = blankIndex % size;

    return (tappedRow == blankRow && (tappedCol - blankCol).abs() == 1) ||
           (tappedCol == blankCol && (tappedRow - blankRow).abs() == 1);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: kTileMoveDuration,
      curve: Curves.easeInOut,
      child: InkWell(
        onTap: () => onTap(currentIndex),
        borderRadius: BorderRadius.circular(8.0),
        key: ValueKey(number), 
        child: Container(
          decoration: BoxDecoration(
            gradient: isMovable
                ? LinearGradient(
                    colors: [kPrimaryColor[300]!, kPrimaryColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : LinearGradient(
                    colors: [kPrimaryColor, kPrimaryColor[600]!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: [
              BoxShadow(
                // FIX: Used .withAlpha instead of deprecated .withOpacity
                color: Colors.black.withAlpha((255 * (isMovable ? 0.5 : 0.3)).round()), 
                offset: const Offset(2, 4),
                blurRadius: 5,
              ),
            ],
            border: Border.all(
              // FIX: Used .withAlpha instead of deprecated .withOpacity
              color: isMovable ? kAccentColor.withAlpha((255 * 0.8).round()) : Colors.transparent,
              width: isMovable ? 3.0 : 0.0,
            ),
          ),
          child: Center(
            child: Text(
              '$number',
              style: TextStyle(
                color: kTextColor,
                fontSize: gridSize < 5 ? 36 : (gridSize < 7 ? 30 : 24),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
      ),
    );
  }
}


